package sid.sl.Foobartory;

/**
 * Hello world!
 *
 */
public class FoobartoryApplication 
{
    public static void main( String[] args )
    {
        Robot robotComportement = new Robot();
        
        robotComportement.seDeplacer();
        robotComportement.minerFoo();
        robotComportement.minierBar();
        robotComportement.assemblerFooBar();
        robotComportement.vendre();
     
    }
}
