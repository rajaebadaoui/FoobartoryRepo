package sid.sl.Foobartory;

public class Robot {

	protected void seDeplacer() {
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
	protected void minerFoo() {
		
		try {
			Thread.sleep(500, 2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	protected void minierBar() {
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
	protected void assemblerFooBar(){
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
	protected void vendre(){
		
		
	}

}
