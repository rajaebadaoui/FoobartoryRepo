package sid.sl.Foobartory;

import java.util.ArrayList;

public class Stock {

	ArrayList<Foo> listFoo;
	ArrayList<Bar> listBar;
}
