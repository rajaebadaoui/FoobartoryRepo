package sid.sl.Foobartory;

public class Foo {

	private int numSerie;
	
	public Foo() {

	}

   public int getNumSerie() {
			return numSerie;
		}
	
    public void setNumSerie(int numSerie) {
			this.numSerie = numSerie;
		}

}
