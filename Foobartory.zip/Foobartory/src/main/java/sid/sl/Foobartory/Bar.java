package sid.sl.Foobartory;

public class Bar {

	private int numSerie;
	
	public Bar() {

	}

	public int getNumSerie() {
		return numSerie;
	}

	public void setNumSerie(int numSerie) {
		this.numSerie = numSerie;
	}

	
}
