package sid.sl.Foobartory;

public class Compte {

	public Compte() {
		
	}

}
